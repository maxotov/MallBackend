-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 08 2016 г., 09:20
-- Версия сервера: 5.5.16
-- Версия PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `mall_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parent` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `title`, `c_date`, `m_date`, `parent`) VALUES
(11, 'Одежда/обувь', '2016-04-22 16:28:42', '2016-04-22 16:28:42', 0),
(12, 'Аксессуары', '2016-04-22 16:28:42', '2016-04-22 16:28:42', 0),
(13, 'Женская одежда', '2016-04-22 16:32:40', '2016-04-22 16:32:40', 11),
(14, 'Женское белье, купальники', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(15, 'Женская обувь', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(16, 'Одежда для беременных', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(17, 'Мужская одежда', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(18, 'Мужское белье', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(19, 'Мужская обувь', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(20, 'Головные уборы', '2016-04-22 16:32:40', '0000-00-00 00:00:00', 11),
(21, 'Ювелирные изделия', '2016-04-22 16:34:59', '0000-00-00 00:00:00', 12),
(22, 'Сумки', '2016-04-22 16:34:59', '0000-00-00 00:00:00', 12),
(23, 'Бижутерия', '2016-04-22 16:34:59', '0000-00-00 00:00:00', 12),
(24, 'Другие аксессуары', '2016-04-22 16:34:59', '0000-00-00 00:00:00', 12),
(25, 'Подарки', '2016-04-22 16:37:54', '0000-00-00 00:00:00', 0),
(26, 'Для свадьбы', '2016-04-22 16:38:18', '0000-00-00 00:00:00', 0),
(27, 'Свадебные аксессуары', '2016-04-22 16:38:51', '0000-00-00 00:00:00', 26),
(28, 'Свадебные платья/костюмы', '2016-04-22 16:38:51', '0000-00-00 00:00:00', 26),
(29, 'Красота/здоровье', '2016-04-22 16:39:42', '0000-00-00 00:00:00', 0),
(30, 'Косметика', '2016-04-22 16:40:55', '0000-00-00 00:00:00', 29),
(31, 'Парфюмерия', '2016-04-22 16:40:55', '0000-00-00 00:00:00', 29),
(32, 'Средства по уходу', '2016-04-22 16:40:55', '0000-00-00 00:00:00', 29),
(33, 'Детский мир', '2016-04-22 16:52:34', '0000-00-00 00:00:00', 0),
(34, 'Детская одежда', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(35, 'Детская обувь', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(36, 'Детские коляски', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(37, 'Детские автокресла', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(38, 'Детская мебель', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(39, 'Игрушки', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(40, 'Товары для школьников', '2016-04-22 16:54:46', '0000-00-00 00:00:00', 33),
(41, 'Канцтовары', '2016-04-22 16:55:28', '0000-00-00 00:00:00', 0),
(42, 'Мебель', '2016-04-22 17:16:50', '0000-00-00 00:00:00', 0),
(43, 'Продукты питания', '2016-04-22 17:16:50', '0000-00-00 00:00:00', 0),
(44, 'Строительство/ремонт', '2016-04-22 17:16:50', '0000-00-00 00:00:00', 0),
(45, 'Овощи/фрукты', '2016-04-22 17:20:37', '0000-00-00 00:00:00', 43),
(46, 'Продуктовый', '2016-04-22 17:20:37', '0000-00-00 00:00:00', 43),
(47, 'Молочные продукты', '2016-04-22 17:20:37', '0000-00-00 00:00:00', 43),
(48, 'Мясной отдел', '2016-04-22 17:20:37', '0000-00-00 00:00:00', 43),
(49, 'Колбасный отдел', '2016-04-22 17:20:37', '0000-00-00 00:00:00', 43);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `shop_id` int(11) NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `view` int(10) NOT NULL,
  `share` int(10) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `description`, `shop_id`, `c_date`, `m_date`, `view`, `share`, `discount`) VALUES
(1, '%D1%81%D2%AF%D1%82+%D1%82%D0%B0%D2%93%D0%B0%D0%BC%D1%8B', 500, '%D1%81%D2%AF%D1%82', 1, '2016-02-14 06:50:37', '2016-02-14 06:50:37', 0, 0, 0),
(2, '%D1%81%D2%AF%D1%82+%D1%82%D0%B0%D2%93%D0%B0%D0%BC%D1%8B', 500, '%D1%81%D2%AF%D1%82', 1, '2016-02-14 06:51:19', '2016-02-14 06:51:19', 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `mall`
--

CREATE TABLE IF NOT EXISTS `mall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lng` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `mall`
--

INSERT INTO `mall` (`id`, `name`, `address`, `lat`, `lng`, `c_date`, `m_date`) VALUES
(1, 'ТД Артем', 'г.Астана, ул.Валиханова, 21/1', '51.173413', '71.436796', '2016-02-06 18:00:00', '2016-02-06 18:00:00'),
(2, 'ТЦ Жаннур', 'г.Астана, пр.Абая, 48', '51.169563', '71.440707', '2016-02-07 09:34:59', '2016-02-06 18:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `goods_id` int(11) NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `role`
--

INSERT INTO `role` (`id`, `name`, `c_date`, `m_date`) VALUES
(1, 'seller', '2016-01-21 18:00:00', '2016-01-21 18:00:00'),
(2, 'client', '2016-01-21 18:00:00', '2016-01-21 18:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `number_shop` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `main_phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `extra_phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `site` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `mall_id` int(11) NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `view` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `shop`
--

INSERT INTO `shop` (`id`, `title`, `number_shop`, `main_phone`, `extra_phone`, `site`, `description`, `user_id`, `mall_id`, `c_date`, `m_date`, `view`) VALUES
(14, 'Жақсы', '178', '87756399896', NULL, NULL, 'Жақсы дүкен', 14, 2, '2016-04-24 10:24:39', '2016-04-24 10:24:39', 0),
(15, 'кәмпиттер', '', '+77475211212', '', '', 'печенье, кәмпит', 14, 1, '2016-04-30 08:18:39', '2016-04-30 12:11:19', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `shop_category`
--

CREATE TABLE IF NOT EXISTS `shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_id` (`shop_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `shop_category`
--

INSERT INTO `shop_category` (`id`, `shop_id`, `category_id`) VALUES
(1, 14, 16),
(2, 14, 17),
(3, 15, 46),
(4, 15, 47);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `device_id` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `phone`, `email`, `password`, `c_date`, `m_date`, `api_key`, `device_id`) VALUES
(6, 'Қажымұқан', '+77774174086', 'ghjg79@gmail.com', '$2a$10$cfce47755b2aab52cd22cOY4GvhGTDAl3y9qmue7j49JZNs7bNRNa', '2015-11-30 18:47:38', '2015-11-30 18:47:38', 'd2a10228ca72a2fec72671b9a4d49c43', '1q2w3e4r5'),
(7, 'nm', '+77775696369', 'nm@mail.ru', '$2a$10$8a2e3cd1223a7f02054bfuhkw/.2JF5AtvFPNEYicQHQgcSnFP2k6', '2016-01-23 16:55:35', '2016-01-26 18:31:57', '25ecbc7fc68080c4e1043163f239d677', 'fhhjhhjk'),
(9, 'ert', '+77775696369', 'ert@mail.ru', '$2a$10$664b373299eba7ab9a43duStzxX.cZyayDNdF0l0LosPxPTObVl3G', '2016-01-26 18:11:21', '2016-01-26 18:30:03', '3035078b5bdc796d1fd1e77dfc1e4bd6', '4r5t6y7'),
(10, 'zxc', '+77775696369', 'zxc@mail.ru', '$2a$10$1e63b2118908aeabad869uYLXkfX8RE.kwB/vPC1Y5dR1A6wID7La', '2016-01-26 18:14:17', '2016-01-26 18:14:17', '982b06dd0493106088aa153253b52e87', '79gfhfhgj4566666666666'),
(11, 'qwe', '+77775696369', 'asdasd@mail.ru', '$2a$10$6f187afc0c721ec4d5e74u1U2vw.Vc2QiQty/ar60XSKm64S90a2a', '2016-01-26 18:12:27', '2016-01-26 18:12:27', 'cc4b69e10519be840f45b208d497dec5', '4456vvvvghh'),
(15, '', '', '', '', '2016-04-09 14:58:07', '2016-04-09 14:58:07', '', 'APA91bGmoQngedhzx34fZnTfzRnDXNWSlda6_rbLugn-4hPQHpEpeYRNcgPgkDOAVyVigNk2E8A3GIRDqkCZ-6GZMBbZ-pRbd8xCLx4yyN32IdFOpnZDVmFYGgBDIE1Kh2-T44XDQvbf'),
(12, 'fgh', '+77775696369', 'fgh@mail.ru', '$2a$10$762229cc9be4039526c20OJYJ09qb7Cd6QZxe5WRUKMRB7s4rAide', '2016-01-26 18:31:19', '2016-01-26 18:31:19', 'f489a86fbb8d57a7e1ef2a981ec69914', '11111111155555555555555'),
(14, 'Айбол', '+77774174086', 'aibol@mail.ru', '$2a$10$eef93590bad11edc65e33OG2b8Y6WX82/Ar.h.KKdSM5O0S86BWtO', '2016-03-13 13:28:40', '2016-03-25 18:34:06', '31e6a1041f13260c3016c7bb3a397037', 'APA91bFKtDtSEmzTDy4s2QgRq43sTq1nOtc8aIABYzv29muUo7wfN2Ux0oLNUjeoF_Dm_TMQ7hNAWB_rEZpcTk5YmEsnX3y8Cw_HPpPcNbslRdq9hG7kk4AFTcpOTVjCbojpAprzAyjg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
